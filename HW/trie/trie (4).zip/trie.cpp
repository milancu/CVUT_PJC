#include "trie.hpp"
#include <iostream>
#include <algorithm>

trie::trie() {
    m_root = new trie_node();
}

trie::trie(const std::vector<std::string> &strings) {
    m_root = new trie_node();
    for (std::string s: strings) {
        insert(s);
    }
}

bool insertHelper(const char *sptr, trie_node *node) {
    char c = *sptr;
    std::cout << "insert helper: " << c << std::endl;

    if (c == 0) {
        if (node->is_terminal) {
            return false;
        }
        node->is_terminal = true;
        return true;
    }

    if (node->children[c] == nullptr) {
        trie_node *newNode = new trie_node();
        newNode->payload = c;
        newNode->parent = node;
        node->children[c] = newNode;
    }

    return insertHelper(sptr + 1, node->children[c]);
}

trie_node *createNewNode(trie_node *parent, char &str) {
    trie_node *newNode = new trie_node();
    newNode->payload = str;
    newNode->parent = parent;
    parent->children[str] = newNode;
    return newNode;
}

bool trie::insert(const std::string &str) {
    trie_node *currNode = m_root;
    if (str == "") {
        m_size++;
        m_root->is_terminal = true;
    }
    for (int i = 0; i < str.size(); i++) {
        char currentChar = str[i];
        if (currNode->children[currentChar] == nullptr) {
            currNode = createNewNode(currNode, currentChar);
        } else {
            currNode = currNode->children[currentChar];
        }
    }
    if (currNode->is_terminal) {
        return false;
    }
    currNode->is_terminal = true;
    m_size++;
    return true;
}


bool eraseHelper(const char *sptr, trie_node *node) {
    char c = *sptr;

    if (c == 0) {
        if (node->is_terminal) {
            node->is_terminal = false;
            return true;
        }
        return false;
    }

    if (node->children[c] == nullptr) {
        return false;
    }

    return eraseHelper(sptr + 1, node->children[c]);
}

bool trie::erase(const std::string &str) {
    if (eraseHelper(str.c_str(), m_root)) {
        --m_size;
        return true;
    }
    return false;
}


bool containsHelper(const char *sptr, trie_node *node) {
    char c = *sptr;

    if (c == 0) {
        return node->is_terminal;
    }

    if (node->children[c] == nullptr) {
        return false;
    }

    return containsHelper(sptr + 1, node->children[c]);
}

bool trie::contains(const std::string &str) const {
    if (containsHelper(str.c_str(), m_root)) {
        return true;
    }
    return false;
}

bool trie::empty() const {
    if (m_size == 0) {
        return true;
    }

    return false;
}

size_t trie::size() const {
    return m_size;
}

void destructHelper(trie_node *node) {
    for (auto c: node->children) {
        if (c != nullptr) {
            destructHelper(c);
        }
    }
    delete node;
}

trie::~trie() {
    destructHelper(m_root);
    m_size = 0;
}

trie_node* beginHelper(trie_node* node) {
    if (node->is_terminal) {
        return node;
    }
    for (int i = 0; i < num_chars; i++) {
        if (node->children[i]) {
            trie_node* ret = beginHelper(node->children[i]);
            if (ret) {
                return ret;
            }
        }
    }
    return nullptr;

}

trie::const_iterator trie::begin() const {
    return trie::const_iterator(beginHelper(m_root));
}

trie::const_iterator trie::end() const {
    return trie::const_iterator();
}

trie_node *findNext(const trie_node *cur, char startChild) {
    for (int i = startChild; i < num_chars; i++) {
        if (cur->children[i]) {
            trie_node *ret = beginHelper(cur->children[i]);
            if (ret) {
                return ret;
            }
        }

    }
    if (cur->parent) { return findNext(cur->parent, cur->payload + 1); }
    return nullptr;
}

void findString(const trie_node *cur, std::string &str) {
    if (cur->payload) {
        str.push_back(cur->payload);
    }

    if (cur->parent) {
        findString(cur->parent, str);
    }
}


trie::const_iterator::reference trie::const_iterator::operator*() const {
    std::string str;
    findString(current_node, str);
    std::reverse(str.begin(), str.end());
    return str;
}

// Define prefix increment operator.
trie::const_iterator &trie::const_iterator::operator++() {
    current_node = findNext(current_node, 0);
    return *this;
}

// Define postfix increment operator.
trie::const_iterator trie::const_iterator::operator++(int) {
    auto temp = *this;
    current_node = findNext(current_node, 0);
    return temp;
}

bool trie::const_iterator::operator==(const trie::const_iterator &rhs) const {
    return current_node == rhs.current_node;
}

bool trie::const_iterator::operator!=(const trie::const_iterator &rhs) const {
    return current_node != rhs.current_node;
}

trie::const_iterator::const_iterator(const trie_node *node) : current_node(node) {
}

/* void */

trie::trie(const trie &rhs) {
    m_root = new trie_node();
    m_size = 0;
}

trie &trie::operator=(const trie &rhs) {
    return *this;
}

trie::trie(trie &&rhs) {
    m_root = new trie_node();
    m_size = 0;
}

trie &trie::operator=(trie &&rhs) {
    return *this;
}

std::vector<std::string> trie::search_by_prefix(const std::string &prefix) const {
    return std::vector<std::string>();
}

std::vector<std::string> trie::get_prefixes(const std::string &str) const {
    return std::vector<std::string>();
}

void trie::swap(trie &rhs) {}

bool trie::operator==(const trie &rhs) const {
    return false;
}

bool trie::operator<(const trie &rhs) const { return false; }

trie trie::operator&(trie const &rhs) const { return *this; }

trie trie::operator|(trie const &rhs) const { return *this; }

bool operator!=(const trie &lhs, const trie &rhs) {
    return false;
}

bool operator<=(const trie &lhs, const trie &rhs) {
    return false;
}

bool operator>(const trie &lhs, const trie &rhs) {
    return false;
}

bool operator>=(const trie &lhs, const trie &rhs) {
    return false;
}

void swap(trie &lhs, trie &rhs) {
}

std::ostream &operator<<(std::ostream &out, trie const &trie) {
    return out;
}