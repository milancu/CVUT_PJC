#include "trie.hpp"

#include <utility>
#include <algorithm>
#include <cassert>
#include <iostream>

using namespace std;

trie::trie() {
    m_root = new trie_node();
    m_size = 0;
}

trie::trie(const trie &rhs) {

}

trie::trie(trie &&rhs) {

}

trie::trie(const vector<string> &strings) {
    m_root = new trie_node();
    m_size = 0;

    for (string s: strings) {
        insert(s);
    }
}

bool findNode(trie_node *node, const std::string &str){
    int i = 0;
    while(node->payload != str[i]){
        i++;
        node = node->children[0];
        if(i == str.size()){
            return false;
        }
    }
    node->parent->children[0] = nullptr;
    return true;
}


bool trie::erase(const std::string &str) {
    if(findNode(m_root->children[0], str)){
        m_size--;
        return true;
    }
    return false;
}

bool trie::insert(const std::string &str) {
    if (str.empty()) {
        return false;
    }

    trie_node *nn;
    trie_node *cn = new trie_node();

    for (int i = 0; i < str.size(); i++) {
        if (i == 0) {
            nn = new trie_node();
            nn->payload = str[i];
            nn->parent = m_root;
            m_root->children[0] = nn;
            m_size++;
            cn = nn;
        } else {
            nn = new trie_node();
            nn->payload = str[i];
            nn->parent = cn;
            cn->children[0] = nn;
            cn = nn;
        }
        if(i == str.size() -1){
            nn->is_terminal = true;
        }
    }
    return true;
}

bool trie::contains(const std::string &str) const {
    if(str.empty()){
        return false;
    }

    if(m_size == 0){
        return false;
    }

    trie_node *cr;
    cr = m_root->children[0];
    for (int i = 0; i < str.size(); i++) {
        cout << cr->payload << " " << str[i] << endl;
        if (cr->payload != str[i]) {
            return false;
        }
        if(i == str.size()-1 && !cr->is_terminal) return false;
        cr = cr->children[0];
    }
    return true;
}

size_t trie::size() const {
    return m_size;
}

bool trie::empty() const {
    if (m_size == 0) {
        return true;
    } else {
        return false;
    }
}

trie::~trie() {
    m_size = 0;
    m_root = nullptr;
}




