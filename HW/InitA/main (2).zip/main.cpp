#include <iostream>

int main() {
    std::cout << "Ahoj cuphuon3" << std::endl;
    return 0;
}
