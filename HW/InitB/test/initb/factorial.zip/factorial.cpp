#include "factorial.hpp"

int factorial(int n) {
    int result = n;
    for (int i = 0; i < n-1; ++i) {
        result = result * n;
    }
    return result;
}
