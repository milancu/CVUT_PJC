#pragma once

// Assume that output will fit int precision, that is N \in [0, 11]
int factorial(int n);
