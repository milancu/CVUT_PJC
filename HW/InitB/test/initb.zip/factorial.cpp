#include "factorial.hpp"

int factorial(int n) {
    // implement me
    return 42;
}
