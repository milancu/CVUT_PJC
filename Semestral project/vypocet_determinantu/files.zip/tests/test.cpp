#include "catch.hpp"


TEST_CASE("basic matrix"){
    REQUIRE(1==1);
}