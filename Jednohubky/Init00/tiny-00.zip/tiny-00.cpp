#include "tiny-00.hpp"
#include <sstream>
#include <utility>
#include <algorithm>
#include <iostream>
#include <iomanip>

using namespace std;

void write_stats(std::vector<double> const& data, std::ostream& out) {
    vector<double> copy = data;
    double min;
    double max;
    double mean;

    for (int i = 0; i < copy.size(); ++i) {
        for (int j = 0; j < copy.size(); ++j) {
            if(j + 1 < copy.size()) {
                if (copy[j] > copy[j + 1]) {
                    swap(copy[j], copy[j + 1]);
                }
            }
        }
    }

    double sum;

    for (double x:copy) {
        sum = sum + x;
    }

    min = copy.at(0);
    max = copy.at(copy.size()-1);
    mean = sum/copy.size();

    out << setprecision (2) << fixed <<"min: "<<min <<"\n"<<"max: "<< max <<"\n"<<"mean: "<< mean << endl;
}

