#include "tiny-00.hpp"
#include <sstream>
#include <utility>
#include <algorithm>
#include <iostream>
#include <iomanip>

using namespace std;

void write_stats(std::vector<double> const& data, std::ostream& out) {
    double min = numeric_limits<double>::infinity();
    double max = - numeric_limits<double>::infinity();
    double mean;

    for (double x : data) {
        if (min > x){min = x;}
        if (max < x){max = x;}
    }

    double sum;

    for (double x:data) {sum = sum + x;}

    mean = sum/data.size();

    out << setprecision (2) << fixed <<"min: "<<min <<"\n"<<"max: "<< max <<"\n"<<"mean: "<< mean << endl;
}

